# coding: utf-8
import tensorflow as tf
from lenovotf.lenovotf import Client
from tornado.gen import Return


def run(main=None, argv=None):
    client = Client()
    success = client.new_cluster()
    if success:
        try:
            success = client.upload_data_and_code()
        except Return as re:
            print(re)

    if success:
        success = client.start_train()
    if success:
        tf.app.run(main, argv)
