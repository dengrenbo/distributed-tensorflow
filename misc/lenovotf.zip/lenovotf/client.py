# coding: utf-8
import logging
import os
import sys
import platform
import re
import json
from lenovotf.util import packagedepends
import lenovotf.util.confReader as reader
import lenovotf.util.httpHelper as fuploader
import configparser
import tensorflow as tf
from optparse import OptionParser

'''the API client who connect API Server to execute commands from driver, include:
1. create a new cluster for user
2. upload train and evaluate data and user code 
3. execute training 
4. fetch logs for training 
5. upload model and provide service 
'''
logging.basicConfig(level=logging.INFO, format="%(asctime)s-%(name)s-%(levelname)s-%(message)s")

try:
    CRNTRAL_ENDPOINT = reader.get_rpc_server_url()
except:
    pass
GLOABLE_CONFIG_PATH = None

# parser = OptionParser(usage="%prog [options]")
# parser.add_option("-c", "--num_cpu", action="store", type="string", dest="num_cpu",
#                   help="number of cpu needed")
# parser.add_option("-g", "--num_gpu", action="store", type="string", dest="num_gpu",
#                   help="number of gpu needed")
# parser.add_option("-w", "--worker", action="store", type="string", dest="worker",
#                   help="number of workers needed")
# parser.add_option("-l", "--num_chief", action="store", type="string", dest="num_chief",
#                   help="number of chief worker needed to run the training")
# parser.add_option("-a", "--memory", action="store", type="string", dest="memory",
#                   help=" memory needed to run the application")
# parser.add_option("-p", "--num_ps", action="store", type="string", dest="ps",
#                   help="number of ps nodes needed")
# parser.add_option("-m", "--mode", action="store", type="string", dest="mode",
#                   help="the distribute mode of this app, options can be single or cluster")
# parser.add_option("-i", "--input", action="store", type="string", dest="input",
#                   help="the data input directory of your application")
# parser.add_option("-o", "--output", action="store", type="string", dest="output",
#                   help="the model output directory of your application")

main_class = None
hdfs_file = None


def get_request(resources):
    request = {}
    if resources:
        request = resources
    else:
        raise ValueError("No resources needed defined, please check and define it.")
    #     (options, args) = parser.parse_args()
    #     resource = {}
    #     if options.mode:
    #         request["mode"] = options.mode
    #     else:
    #         raise RuntimeError("runtime parameter [mode] is not specified ,use -m or --mode to define it.")
    #         sys.exit(-1)
    #     if options.num_cpu:
    #         resource["cpu"] = int(options.num_cpu)
    #     else:
    #         raise RuntimeError("runtime parameter [cpu] is not specified ,use -c or --num_gpu to define it.")
    #     if options.num_gpu:
    #         resource["gpu"] = int(options.num_gpu)
    #     else:
    #         raise RuntimeError("runtime parameter [gpu] is not specified ,use -g or --num_cpu to define it.")
    #     if options.memory:
    #         resource["memory"] = options.memory
    #     else:
    #         raise RuntimeError("runtime parameter [memory] is not specified ,use -a or --memory to define it.")
    #     request["resource"] = resource
    #     detail = {}
    #     if options.num_chief:
    #         detail["chief"] = options.num_chief
    #     else:
    #         detail["chief"] = 0
    #     if options.ps:
    #         detail["ps"] = options.ps
    #     else:
    #         detail["ps"] = 0
    #     if options.worker:
    #         detail["worker"] = options.worker
    #     else:
    #         detail["worker"] = 1
    #     request["detail"] = detail
    #     # request["file"] = "/code/tf-estimator-cluster-app_with_dependences.zip"
    #     # request["main"] = "/tf_dis/tf-estimator-cluster-app.py"
    #     if hdfs_file:
    #         request["file"] = hdfs_file
    #     if main_class:
    #         # request["main"] = "/tf_dis/tf-estimator-cluster-app.py"
    #         request["main"] = main_class
    #     else:
    #         raise RuntimeError("No main class found.")
    #     if options.output:
    #         request["export"] = options.output
    #     else:
    #         raise ValueError(
    #             "no model dir set in your application,pls set it by run config or pass it as execution argument using -o or --output.")
    request["python"] = platform.python_version()
    request["type"] = "tensorflow"
    request["version"] = tf.__version__
    if hdfs_file:
        request["file"] = hdfs_file
    request["main"] = main_class
    return request


class Client:
    file = None

    def __init__(self):
        # self.cRpcClient.start()
        self.cluster = None

    def new_cluster(self, resources):
        logging.info('Preparing to get cluster resources from server...')
        request = get_request(resources)
        print(request)
        self.do_request(request)
        return True

    def do_request(self, request):

        def handle_request(response):
            if response.error:
                logging.error("Error:", response.error)
            else:
                logging.info(response.body)

        # http_client = AsyncHTTPClient()
        server_url = "http://172.17.171.190:12345/v1/train"
        import requests
        import json
        res = requests.post(server_url, json.dumps(request))
        if res.status_code == 200:
            # if True:
            content = res.content.decode()
            nodes = re.sub("[\[\]\"]", "", res.content.decode()).split(",")
            print(content)
            # nodes = ["tf-318ccc82-0a3f-11e9-8be9-fa163ef8da8a-worker-0-2",
            #          "tf-318ccc82-0a3f-11e9-8be9-fa163ef8da8a-worker-1-2",
            #          "tf-318ccc82-0a3f-11e9-8be9-fa163ef8da8a-chief-1-1"]
            logging.info(
                "Success in getting resources of application, fetching cluster monitoring and log information...")
            self._fetch_logs(nodes)
        else:
            logging.error("Failed getting resources for your application; message from server: %s, please try again.",
                          res.reason)
        # return res

    def _fetch_logs(self, nodes=[]):
        ''' fetch logs for each nodes in a cluster,
        try to fetch 10 log records every time, cause logs will be continuously produced'''
        from elasticsearch.client import Elasticsearch
        es = Elasticsearch(hosts=[{"host": "172.17.171.190", "port": 30092}])
        import time
        index = "logstash-" + time.strftime('%Y.%m.%d', time.localtime())
        # index = "logstash-2018.12.26"
        _source_include = ["log", "@timestamp", "offset", "tf-tag"]
        batch_size = 10
        retry_count = 0
        max_retry = 10
        is_retry = False
        is_stop = False
        tf_tag_to_offsets = {}
        while not is_stop:
            for node in nodes:
                # first time to fetch logs
                if tf_tag_to_offsets.keys().__contains__(node):
                    query = self._build_offset_filter(node, batch_size, tf_tag_to_offsets[node])
                else:
                    query = self._build_match(node, batch_size)
                task = node.split("-")[-2:-4:-1]  #
                task = task[-1] + "-" + str(int(task[0]) + 1)
                # res = es.search(index=index, body=query_a, _source_include=_source_include, scroll="1m")
                # 这里每次取10条不需要构建分页
                res = es.search(body=query, _source_include=_source_include)
                is_stop, tf_tag_to_offsets[node] = self._print_logs(res["hits"]["hits"], task)

            #  if training has not been stop, then keep fetch logs every 5 seconds
            logging.info("Fetching logs, please wait...")
            time.sleep(5)

    def _check_log_error(self, log):
        return bool(re.search("error", log, re.IGNORECASE)) or bool(re.search("fail", log, re.IGNORECASE))

    def _build_match(self, tf_tag, size):
        return {
            "query": {
                "bool": {
                    "must": [
                        {"match": {
                            "tf-tag": {
                                "query": tf_tag,
                                "type": "phrase"  # 必须指明，否则会出现模糊匹配
                            }
                        }}
                    ]
                }

            }, "size": size, "sort": [{"@timestamp": {"order": "asc"}}, {"offset": {"order": "asc"}}]
        }

    def _build_offset_filter(self, tf_tag, size, max_offset):
        return {
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "offset": {
                                    "gt": max_offset
                                }
                            }
                        }, {"match": {
                            "tf-tag": {
                                "query": tf_tag,
                                "type": "phrase"
                            }
                        }}
                    ]
                }

            }, "size": size, "sort": [{"@timestamp": {"order": "asc"}}, {"offset": {"order": "asc"}}]

        }

    def _print_logs(self, logs, task):
        max_offset = None
        global is_stop
        is_stop = False
        for log in logs:
            logging.info(
                "%s,%s:%s" % (log["_source"]["@timestamp"], task, log["_source"]["log"]))
            # TODO 判断日志收集是否结束
            # if log["-source"]["log"].__contains__():
            #     is_stop = True
            max_offset = log["_source"]["offset"]
        return is_stop, max_offset

    def upload_data_and_code(self, entrance_class=sys.argv[0], data_dir=None):
        cdir = os.path.abspath(".")
        # 指定tf启动类作为参数
        installed = reader.get_pre_installed_depends()
        file = packagedepends.package(entrance_class, excludes=installed, datas=data_dir)
        global main_class
        main_class = self._get_main_path(file)
        logging.info('Preparing to uploading code ...')
        upres = fuploader.uploadfile(file)
        if upres and upres.status_code != 200:
            logging.error("An " + upres.reason + " happened on server,pls try again...")
        else:
            file = json.loads(upres.content.decode())["file"]
        if file:
            logging.info("Codes are stored by server as : %s" % file)
        logging.info("repackage code on server,pls wait...")
        res = fuploader.package(file)
        if res and res.status_code != 200:
            logging.error("An " + res.reason + " happened on server,pls try again...")
        else:
            file = json.loads(res.content.decode())["file"]
        if file and file != "":
            logging.info("Done repackage code as: %s" % file)
        else:
            raise ValueError("Failed while repackaging codes on server, no repackaged file found.pls try again.")
        global hdfs_file
        # TODO 更换hdfs文件名
        hdfs_file = file
        return True

    def upload_data_and_code_test(self, entrance_class=sys.argv[0], data_dir=None):
        cdir = os.path.abspath(".")
        # 指定tf启动类作为参数
        installed = reader.get_pre_installed_depends()
        # file = "F:\\PythonWorkspace\\tf-package-demo\\tf-estimator-cluster-app.zip"
        # file = "F:/PythonWorkspace/tf-package-demo/tf-estimator-cluster-app.zip"
        # include = [("F:\\PythonWorkspace\\tf-package-demo\\lenovotf\\conf\\app.conf", "lenovotf/conf/app.conf")]
        # file = packagedepends.package(entrance_class, excludes=installed, datas=data_dir)
        file = "/data/tfcodes/upload/tf-estimator-cluster-app.zip"
        # # print(file)
        global main_class
        main_class = "/tf_dis/tf-estimator-cluster-app.py"
        # main_class = self._get_main_path(file)
        logging.info('preparing to uploading code ...')
        # upres = fuploader.uploadfile(file)
        # if upres and upres.status_code != 200:
        #     logging.error("An " + upres.reason + " happened on server,pls try again...")
        # else:
        #     file = json.loads(upres.content.decode())["file"]
        # file = "/data/tfcodes/upload/tf-estimator-cluster-app.zip"
        # if file:
        #     logging.info("codes stored by server as : %s" % file)
        # logging.info("repackage code on server,pls wait...")
        # res = fuploader.package(file)
        # if res and res.status_code != 200:
        #     logging.error("An " + res.reason + " happened on server,pls try again...")
        # else:
        #     file = json.loads(res.content.decode())["file"]
        # if file and file != "":
        #     logging.info("Done repackage code as: %s" % file)
        # else:
        #     raise ValueError("Failed while repackaging codes on server, no repackaged file found.pls try again.")
        # global hdfs_file
        # TODO 更换hdfs文件名
        hdfs_file = "/code/tf-estimator-cluster-app_with_dependences.zip"
        # hdfs_file = file
        return True

    def upload_code(self, code_file, cluster):
        # 用户源码上传至服务器,服务端接口代码完成后进行部署
        logging.info('preparing to uploading code ...')
        # fuploader.upload_file([code_file])
        # self.cRpcClient.distribute_code(self._app_id, cluster)
        # self.cRpcClient.dis_code(code_file, cluster)
        return fuploader.uploadfile(code_file)

    def start_train(self):
        logging.info('preparing to start training...')
        c = {
            'cluster': {'chief': ['localhost:2222'],
                        'ps': ['localhost:2223', 'localhost:2224'],
                        'worker': ['localhost:2224', 'localhost:2225']},
            'hosts': [{'host': 'localhost:2222', 'task': {'type': 'worker', 'index': 0}},
                      {'host': 'localhost:2224', 'task': {'type': 'worker', 'index': 1}}]
        }
        # self.cRpcClient.train(sys.argv[0])
        # TODO 启动各节点训练脚本，开始训练
        return True

    def deploy_model(self):
        logging.info('preparing to deploy model...')
        # TODO 部署模型至服务器，启动模型服务
        return True

    def _get_main_path(self, file):
        import platform
        if platform.system() == "Windows":
            file = str(file.encode('unicode_escape'))
            file = re.sub("[b']", "", file)
            file = file.replace("\\\\", "/")
            file = re.sub("//", "/", file)
        main_real_path = re.sub(os.path.dirname(file), "", os.path.dirname(sys.argv[0]))
        return main_real_path + "/" + os.path.basename(sys.argv[0])
