# coding: utf-8
import tensorflow as tf
import os
import tensorflow.estimator as es
import logging
import sys

logging.basicConfig(level=logging.INFO, format="%(asctime)s-%(name)s-%(levelname)s-%(message)s")


def train_and_evaluate(estimator, train_spec, eval_spec, resources):
    ''' begin training with the resources needed
    ::param resources: a dictionary the resources needed to run this appliation
    eg.
    {
    "mode": "cluster",
    "resource": {
        "cpu": 2,
        "mem": "4g",
        "gpu": 1
    },
    "detail": {
        "ps": 1,
        "worker": 2,
        'chief': 1
    },
    "train_data_dir":["abc/input"],
    "eval_data_dir":["abc/input"]
    }
    in the example above ,[mode] means cluster mode. options can be "single" or "cluster".
    train_data_dir is a list of path which train data in
    eval_data_dir is a list of path which evaluate data in
    '''
    # 训练时mode为0
    mode = "0"
    try:
        mode = int(os.environ['RUN_MODE'])
    except:
        KeyError
        mode = "1"

    # 此处如果在工作节点上执行，则直接屏蔽生成资源等操作，直接进入训练流程
    if mode == 0:
        tf.estimator.train_and_evaluate(estimator=estimator, train_spec=train_spec, eval_spec=eval_spec)
    else:
        # avoid import exception
        from lenovotf.client import Client
        client = Client()
        _check_resource(resources)
        resources["export"] = estimator.config.model_dir
        # print(model_dir)
        # NOTE: 此处可能存在服务器打包操作过于耗时导致请求超时
        success = client.upload_data_and_code(entrance_class=sys.argv[0], data_dir=_construct_data_dir(resources))
        # success = client.upload_data_and_code_test(entrance_class=sys.argv[0], data_dir=_construct_data_dir(resources))
        if success:
            success = client.new_cluster(resources)


def _check_resource(resources):
    if resources:
        if not resources["mode"]:
            logging.error("no cluster mode is defined, please set it as resources[\"mode\"].")
        if not resources["resource"]:
            logging.error("no resource is defined, please set it as resources[\"resource\"].")
        if not resources["detail"]:
            logging.error("no resource details is defined, please set it as resources[\"detail\"]")
        if not resources["train_data_dir"]:
            logging.error("no train_data_dir details is defined, please set it as resources[\"train_data_dir\"]")
    else:
        logging.error(
            "No resources specified, please pass it as a argument when call method [estimator.train_and_evaluate]")


def _construct_data_dir(resources):
    '''construct a data file list if local train and evaluate data are uesed
    ::param resources'''
    global train_data_dir
    global eval_data_dir
    try:
        train_data_dir = resources.pop("train_data_dir")
    except KeyError:
        raise KeyError("no training data input directory is specified in resources.")
    try:
        eval_data_dir = resources.pop("eval_data_dir")
    except KeyError:
        raise KeyError("no training data input directory is specified in resources.")
    data = _construct_data(train_data_dir)
    data.extend(_construct_data(eval_data_dir))
    # print(data)
    # sys.exit(0)
    return data


def _construct_data(data_dir):
    data = []
    for dir in data_dir:
        if os.path.isdir(dir):
            train_files = os.listdir(dir)
            for file in train_files:
                if dir.endswith("/") or dir.endswith("\\" or dir.endswith("\\\\")):
                    data.append((dir + file, dir))
                else:
                    data.append((dir + "/" + file, dir))
        if os.path.isfile(dir):
            data.append((dir, dir))
    return data

# 该方法属于keras estimator, 暂不考虑
def train(estimator, train_input_fn):
    mode = "0"
    try:
        mode = int(os.environ['RUN_MODE'])
    except:
        KeyError
        mode = "1"
    if mode == 0:
        estimator.train(train_input_fn)
    else:
        from lenovotf.lenovotf import Client
        client = Client()
        # success = client.upload_data_and_code()
        # if success:
        success = client.new_cluster()
        # if success:
        #     success = client.start_train()
        #     estimator.train(train_input_fn)

    # global train_success
    # train_success = success


def evaluate(estimator, eval_input_fn):
    estimator.evaluate(eval_input_fn)


_USE_DEFAULT = object()


class RunConfig(object):
    def __init__(self,
                 model_dir=None,
                 tf_random_seed=None,
                 save_summary_steps=100,
                 save_checkpoints_steps=_USE_DEFAULT,
                 save_checkpoints_secs=_USE_DEFAULT,
                 session_config=None,
                 keep_checkpoint_max=5,
                 keep_checkpoint_every_n_hours=10000,
                 log_step_count_steps=100,
                 train_distribute=None,
                 device_fn=None,
                 protocol=None,
                 eval_distribute=None,
                 experimental_distribute=None):
        self.config = es.RunConfig(model_dir, tf_random_seed, save_summary_steps, save_checkpoints_steps,
                                   save_checkpoints_secs, session_config, keep_checkpoint_max,
                                   keep_checkpoint_every_n_hours, log_step_count_steps, train_distribute, device_fn,
                                   protocol, eval_distribute, experimental_distribute)
