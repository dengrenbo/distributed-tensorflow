import tornado.web
from tornado.escape import json_decode, json_encode
import re
import os
from tornado import gen

import logging

try:
    from urllib.parse import unquote
except ImportError:
    # Python 2.
    from urllib import unquote

logging.basicConfig(level=logging.INFO)

FILE_DIR_PREFIX = "/data/tfcodes/upload/"


# FILE_DIR_PREFIX = "f:/test/"


class FileHandler(tornado.web.RequestHandler):
    def get(self):
        self.write("Hello, world")

    @gen.coroutine
    def post(self):
        for field_name, files in self.request.files.items():
            for info in files:
                filename, content_type = info["filename"], info["content_type"]
                body = info["body"]
                print(body)
                filename = re.sub("\\\\", "/", filename)
                filename = re.split("/", filename)[-1]
                file = FILE_DIR_PREFIX + filename
                logging.info("storing file:%s..." % file)
                if not os.path.exists(FILE_DIR_PREFIX):
                    os.system("mkdir -p %s" % FILE_DIR_PREFIX)
                with open(file, 'wb') as f:
                    f.write(body)
                # print(body)
                logging.info(
                    'POST "%s" "%s" %d bytes', filename, content_type, len(body)
                )
                depfile = re.split("\.", file)[0] + "_with_dependences.zip"
                logging.info("start package and  upload thread...")
                pkcmd = "python repackage.py %s" % file
                os.system(pkcmd)
                dfs_file = "/code/%s" % re.split("\.", filename)[0] + "_with_dependences.zip"
                delcmd = "hadoop fs -rm %s" % dfs_file
                logging.info("executing delete cmd:%s" % delcmd)
                # delete file first if it exists or else it won't be overwrite
                os.system(delcmd)
                putcmd = "hadoop fs -put %s /code/" % self.dep_file
                os.system(putcmd)
                self.write(json_encode({"file": dfs_file}))
