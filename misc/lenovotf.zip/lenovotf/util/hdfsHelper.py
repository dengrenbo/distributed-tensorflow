from hdfs.client import Client
from hdfs.util import HdfsError


def putfile(file):
    print("puting file...")
    client = Client("http://172.17.171.190:50070/")
    try:
        # print(client.list("/"))
        print(client)
        # print(client.upload(hdfs_path="/code/", local_path="../../tf-estimator-cluster-app.zip", overwrite=True))
        print(client.makedirs("/code/test"))
    except HdfsError as e:
        raise e

    # client.write("/tf/", "123")
    # client.upload(file, file, overwrite=True, progress=call_back)


def call_back():
    print("call back function..")


import sys

print(sys.path)
putfile(None)
