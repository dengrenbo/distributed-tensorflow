"""Usage: python httpHelper.py [--put] file1.txt file2.png ...
Demonstrates uploading files to a server, without concurrency. It can either
POST a multipart-form-encoded request containing one or more files, or PUT a
single file without encoding.
See also file_receiver.py in this directory, a server that receives uploads.
"""

import sys
import lenovotf.util.confReader as reader

try:
    from urllib.parse import quote
except ImportError:
    # Python 2.
    from urllib import quote

from tornado.options import define, options
import logging
import requests

logging.basicConfig(level=logging.INFO)

SERVER_URL = reader.get_web_server_url()


# SERVER_URL = "http://localhost:8888"


# Using HTTP POST, upload one or more files in a single multipart-form-encoded

def uploadfile(filename):
    if not filename:
        logging.error("Provide a  filename to upload.", file=sys.stderr)
        sys.exit(1)
    # return requests.post("http://localhost:8888" + "/post",
    #                      files={"file": (filename, (open(filename, "rb")))}).content.decode()
    return requests.post(SERVER_URL + "/file", files={"file": (filename, (open(filename, "rb")))})


def package(filename):
    if not filename:
        logging.error("Provide a  to repackage.", file=sys.stderr)
        sys.exit(1)
    # return requests.get("http://localhost:8888" + "/package",
    #                     params={"file": filename.encode("utf-8")}).content.decode()
    print(filename)
    import platform
    response = None
    try:
        response = requests.get(SERVER_URL + "/package",
                                params={"file": filename.encode("utf-8"),
                                        "python": platform.python_version()})
    except requests.exceptions.Timeout:
        # if its the first time to repackage code,if too many dependencies need,
        # it may cost much time to download those depends which can cause a timeout exception.
        # retry to connect the server again and check whether the repackage is done and a file "with dependency exists"
        # the default retry time is 30 times.
        for i in range(1, 30):
            logging.info("Connection timeout,retry count=%s, total retry times = 30,retry interval = 2s" % i)
            response = requests.get(SERVER_URL + "/file", params={"file": filename.encode("utf-8")})
            import time
            time.sleep(2)

    return response


def deploy_to_cluster(cluster):
    pass


if __name__ == "__main__":
    define("put", type=bool, help="Use PUT instead of POST", group="file uploader")

    # Tornado configures logging from command line opts and returns remaining args.
    filenames = options.parse_command_line()
    # filenames = ['F:/PythonWorkspace/easytf/test/fab_test.py']
    filenames = ['F:\\PythonWorkspace\\tf-package-demo\\tf-estimator-cluster-app.zip']
    filename = 'F:/PythonWorkspace/tf-package-demo/tf-estimator-cluster-app.zip'
    if not filenames:
        print("Provide a list of filenames to upload.", file=sys.stderr)
        sys.exit(1)

    import requests

    # print(requests.post(server_url, files={"file": (filename, (open(filename, "rb")))}))
    params = {"file": filename.encode("utf-8")}
    # res = requests.get(server_url, params)
    res = package(filename)
    print(res)

    # file = "F:\\PythonWorkspace\\tf-package-demo\\tf-estimator-cluster-app.zip"
    # post(file, "localhost:8888")
