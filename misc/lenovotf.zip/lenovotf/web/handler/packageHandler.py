import tornado.web
from tornado.escape import json_decode, json_encode
import re
import os
import subprocess

import logging

try:
    from urllib.parse import unquote
except ImportError:
    # Python 2.
    from urllib import unquote

logging.basicConfig(level=logging.INFO, format="%(asctime)s-%(name)s-%(levelname)s-%(message)s")

FILE_DIR_PREFIX = "/data/tfcodes/upload/"


class PackageHandler(tornado.web.RequestHandler):

    def get(self):
        # don't know why its a list
        filename = self.get_argument("file")
        python = self.get_argument("python")
        # filename = re.sub("\\\\", "/", filename)
        filename = re.split("/", filename)[-1]
        file = FILE_DIR_PREFIX + filename
        # while True:
        #     print("-")
        if not os.path.exists(file):
            self.write(json_encode({"file": ""}))
            # raise FileNotFoundError("No file named %s found" % file)
        tmpfile = re.split("\.", file)[0] + "_tmp_"
        depfile = re.split("\.", file)[0] + "_with_dependences.zip"
        logging.info("removing temp file " + tmpfile)
        if os.path.exists(tmpfile):
            os.system("rm -rf " + tmpfile)
        logging.info("removing old packaged codes...")
        if os.path.exists(depfile):
            os.system("rm -f %s" % depfile)
        py27 = "/root/anaconda2/bin/python2.7"
        py34 = "/root/anaconda2/envs/py34/bin/python3.4"
        py35 = "/root/anaconda2/envs/py35/bin/python3.5"
        py36 = "/root/anaconda2/envs/py36/bin/python3.6"
        if python.startswith("2.7"):
            pkcmd = "%s repackage.py %s" % (py27, file)
        elif python.startswith("3.4"):
            pkcmd = "%s repackage.py %s" % (py34, file)
        elif python.startswith("3.5"):
            pkcmd = "%s repackage.py %s" % (py35, file)
        elif python.startswith("3.6"):
            pkcmd = "%s repackage.py %s" % (py36, file)
        else:  # default: use python2.7
            pkcmd = "python repackage.py %s" % file
        logging.info("Start packaging codes, command: %s ..." % pkcmd)
        os.system(pkcmd)
        hdfs_file = "/code/" + depfile.split("/")[-1]
        delcmd = "hadoop fs -rm %s" % hdfs_file
        logging.info("executing delete cmd:%s" % delcmd)
        # delete file first if it exists or else it won't be overwrite
        if "Deleted" in os.popen(delcmd).read():
            logging.info("delete file: %s on hdfs." % hdfs_file)
        else:
            logging.warning("no file named %s on hdfs found." % hdfs_file)
        putcmd = "hadoop fs -put %s /code/" % depfile
        # no extra depends needed so that codes have not been repackaged, then upload original  codes to hdfs.
        if not os.path.exists(depfile):
            logging.warning("No repackaged file nameed <%s> found,uploading original zip file <%s> to hdfs." % (depfile,
                                                                                                                file))
            hdfs_file = "/code/" + file.split("/")[-1]
            putcmd = "hadoop fs -put %s /code/" % file
        logging.info("Start  uploading codes to HDFS, command: %s ..." % putcmd)
        os.system(putcmd)
        logging.info("done package and upload file : %s to hdfs" % hdfs_file)
        self.write(json_encode({"file": hdfs_file}))
